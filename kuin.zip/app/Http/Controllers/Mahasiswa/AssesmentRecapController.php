<?php

namespace App\Http\Controllers\Mahasiswa;

use App\Models\AnswerMc;
use App\Models\AttemptQuiz;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AssesmentRecapController extends Controller
{
    protected function showAssesmentRecap()
    {
        $user = auth()->user();
        $attempt = null;
        $total_skor = 0;

        if ($user->level === 'admin' || $user->level === 'dosen') {
            // Jika admin atau dosen, ambil semua data AttemptQuiz
            $attempt = AttemptQuiz::all();

            // Inisialisasi total skor untuk admin atau dosen
            $total_skor = 0;

            // Iterasi melalui setiap AttemptQuiz
            foreach ($attempt as $item) {
                // Mengambil total skor untuk setiap quiz_id berdasarkan user_id_attempt
                $quiz_id = $item->quiz_id;
                $user_id_attempt = $item->user_id;
                $skor_per_quiz = AnswerMc::where('user_id', $user_id_attempt)
                    ->where('quiz_id', $quiz_id)
                    ->sum('score');

                // Menambahkan skor dari quiz ini ke total skor admin atau dosen
                $total_skor += $skor_per_quiz;
            }
        } else {
            // Jika bukan admin atau dosen, ambil data AttemptQuiz berdasarkan user_id
            $attempt = AttemptQuiz::where('user_id', $user->user_id)->get();

            // Inisialisasi total skor untuk pengguna saat ini
            $total_skor = 0;

            // Iterasi melalui setiap AttemptQuiz pengguna
            foreach ($attempt as $item) {
                // Mengambil total skor untuk setiap quiz_id berdasarkan user_id
                $quiz_id = $item->quiz_id;
                $skor_per_quiz = AnswerMc::where('user_id', $user->user_id)
                    ->where('quiz_id', $quiz_id)
                    ->sum('score');

                // Menambahkan skor dari quiz ini ke total skor pengguna
                $total_skor += $skor_per_quiz;
            }
        }

        $data = [
            'title' => 'Assesment Recap',
            'id_page' => 15,
            'attempt' => $attempt,
            'total_skor' => $total_skor,
            'user' => $user,
        ];

        return view('mahasiswa.assesment_rekap', $data);
    }
}
